#!/bin/bash 
cd /tmp/finn_dev_stefan/vivado_stitch_proj_v03nnx92
vivado -mode batch -source make_project.tcl
cd /home/stefan/finn
